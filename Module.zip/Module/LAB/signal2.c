#include <stdio.h>
#include <signal.h>
#include <unistd.h>
int main() {
	printf("Before SIGKILL...\n");
	raise(SIGKILL);
	printf("After SIGKILL...\n");

    return 0;
}
