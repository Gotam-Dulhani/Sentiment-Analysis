#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/resource.h>
#include <unistd.h>

void proc_exit() {
    int wstat;
    pid_t pid;

    while (1) {
        // Get info about child process (non-blocking)
        pid = wait3(&wstat, WNOHANG, NULL);

        if (pid == 0 || pid == -1) {
            fprintf(stdout, "return value of wait3() is %d\n", pid);
            return;
        }

        fprintf(stdout, "Return code: %d\n", wstat);
    }
}

int main() {
    // Register signal handler
    signal(SIGCHLD, proc_exit);

    switch (fork()) {

        case -1:
            perror("main: fork");
            exit(1);

        case 0: {
            // Child process
            printf("I'm alive (temporarily)\n");

            int ret_code = rand() % 100;
            printf("Return code is %d\n", ret_code);

            exit(ret_code);
        }

        default:
            // Parent process waits for signal
            pause();
    }

    exit(0);
}
