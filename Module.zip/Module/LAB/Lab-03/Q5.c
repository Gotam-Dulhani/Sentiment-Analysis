#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
    int fd1 = open("input.txt", O_RDONLY);
    if(fd1 < 0) {
        perror("Error opening input file");
        return 1;
    }

    int fd2 = open("output.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if(fd2 < 0) {
        perror("Error opening output file");
        return 1;
    }

    char buffer[1024];
    int bytes;

    while((bytes = read(fd1, buffer, sizeof(buffer))) > 0) {
        write(fd2, buffer, bytes);
    }

    close(fd1);
    close(fd2);

    return 0;
}
