#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main(){
    //zombie
    pid_t pid;
    pid = fork();

    if(pid == 0){
        printf("Child process\n");

        return 0;
    }

    else{
        printf("Parent Process process\n");

        sleep(40);
    }

}