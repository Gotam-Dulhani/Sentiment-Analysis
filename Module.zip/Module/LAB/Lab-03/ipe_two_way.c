#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main(){
    char msg_child[20] = "Hello Parent";
    char msg_parent[20] = "Hello Child";
    char buffer[20];

    int pipe1[2], pipe2[2];

    pipe(pipe1);
    pipe(pipe2);

    pid_t pid;

    pid = fork();

    if(pid == 0){
        close(pipe2[1]); //closed writting end for child pipe2
        close(pipe1[0]); //closed reading end for child pipe1
        printf("Child Writting... \t\n");

        write(pipe1[1], msg_child, 20);

        read(pipe2[0], buffer, 20);
        printf("Child Process Reading..\n");
        printf("msg from parent %s", buffer);
    }

    else{
        close(pipe2[0]); //closing reading end for parent pipe2
        close(pipe1[1]); //closing writting end for parent pipe1
        read(pipe1[0], buffer, 20);
        printf("Parent Process Reading..\n");
        printf("msg from child %s", buffer);
        printf("\nParent Writting...\n");
        write(pipe2[1], msg_parent, 20);
    }

    return 0;
}