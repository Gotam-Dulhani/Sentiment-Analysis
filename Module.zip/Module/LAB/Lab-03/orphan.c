#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main(){
    //orphan
    pid_t pid;
    pid = fork();

    if(pid == 0){
        printf("Child process\n");

        sleep(40);
    }

    else{
        printf("Parent Process process\n");

        return 0;
    }

}