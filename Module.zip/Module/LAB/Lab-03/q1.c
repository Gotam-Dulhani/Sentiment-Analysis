#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t c1, c2;

    c1 = fork();

    if (c1 == 0) {
        printf("Child 1 PID: %d\n", getpid());
        return 0;
    }

    c2 = fork();

    if (c2 == 0) {
        printf("Child 2 PPID: %d\n", getppid());
        return 0;
    }

    wait(NULL);
    wait(NULL);

    printf("Parent finished\n");
    return 0;
}
