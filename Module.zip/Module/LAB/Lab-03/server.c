#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>

#define FIFO "myfifo"

int main()
{
    int fd;
    char buffer[100];

    // Create FIFO (ignore if already exists)
    mkfifo(FIFO, 0666);

    // Open FIFO in read-write mode
    fd = open(FIFO, O_RDWR);

    //Read message from client
    read(fd, buffer, sizeof(buffer));
    printf("Server received: %s\n", buffer);

    //Send reply to client
    char reply[] = "Hello from Server";
    write(fd, reply, strlen(reply)+1);

    close(fd);
    return 0;
}