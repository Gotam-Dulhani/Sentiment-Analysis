#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(){
    int fd[2];
    pid_t pid;

    pipe(fd);

    pid = fork();

    if (pid > 0){
        close(fd[0]);

        int temperature, humidity;

        printf("Enter Temperature: ");
        scanf("%d", &temperature);

        printf("Enter Humidity: ");
        scanf("%d", &humidity);

        write(fd[1], &temperature, sizeof(temperature));
        write(fd[1], &humidity, sizeof(humidity));

        close(fd[1]);
    }
    else {
        close(fd[1]);

        int temperature, humidity;

        read(fd[0], &temperature, sizeof(temperature));
        read(fd[0], &humidity, sizeof(humidity));

        printf("Received Temp: %d, Humidity: %d\n", temperature, humidity);

        if (temperature > 40) {
            printf("ALERT: High Temperature!\n");
        } else {
            printf("Normal Weather Conditions\n");
        }

        close(fd[0]);
    }

    return 0;
}


