#include <stdio.h>
#include <pthread.h>
#include <time.h>

#define SIZE 1000000
#define THREADS 4

int arr[SIZE];
long long sum = 0;

typedef struct {
    int start, end;
} Data;

void *partial_sum(void *arg){
    Data *d = (Data *)arg;
    long long local = 0;

    for (int i = d->start; i < d->end; i++)
        local += arr[i];

    sum += local;   //race condition
    return NULL;
}

double time_diff(struct timespec s, struct timespec e){
    return (e.tv_sec - s.tv_sec) + (e.tv_nsec - s.tv_nsec)/1e9;
}

int main(){
    struct timespec start, end;

    for(int i = 0; i < SIZE; i++)
        arr[i] = 1;

    //SERIAL
    sum = 0;
    clock_gettime(CLOCK_MONOTONIC, &start);

    for(int i = 0; i < SIZE; i++)
        sum += arr[i];

    clock_gettime(CLOCK_MONOTONIC, &end);

    double serial_time = time_diff(start, end);
    printf("Serial Sum = %lld\n", sum);
    printf("Serial Time = %f sec\n\n", serial_time);

    //MULTITHREAD
    sum = 0;
    pthread_t t[THREADS];
    Data d[THREADS];

    int chunk = SIZE / THREADS;

    clock_gettime(CLOCK_MONOTONIC, &start);

    for(int i = 0; i < THREADS; i++){
        d[i].start = i * chunk;
        d[i].end = (i == THREADS-1) ? SIZE : (i+1)*chunk;

        pthread_create(&t[i], NULL, partial_sum, &d[i]);
    }

    for(int i = 0; i < THREADS; i++)
        pthread_join(t[i], NULL);

    clock_gettime(CLOCK_MONOTONIC, &end);

    double thread_time = time_diff(start, end);

    printf("Thread Sum = %lld\n", sum);
    printf("Thread Time = %f sec\n", thread_time);

    return 0;
}


