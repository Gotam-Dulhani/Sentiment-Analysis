#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

#define FIFO_NAME "atm_fifo"

int main(){
    char buffer[100];
    
    mkfifo(FIFO_NAME, 0666);

    while (1) {
        int fd = open(FIFO_NAME, O_RDONLY);
        read(fd, buffer, sizeof(buffer));

        printf("Server received: %s", buffer);

        int acc, pin;
        sscanf(buffer, "%d %d", &acc, &pin);

        if (acc == 1234 && pin == 4321){
            printf("Response: Valid, Balance: $5000\n\n");
        } else {
            printf("Response: Invalid Credentials\n");
        }

        close(fd);
    }

    return 0;
}


